public interface Notification {
    void envoyer(String message);
}
