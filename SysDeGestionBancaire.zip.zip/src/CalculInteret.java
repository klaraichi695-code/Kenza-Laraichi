public interface CalculInteret {
    double calculerInteret(double solde);
}

