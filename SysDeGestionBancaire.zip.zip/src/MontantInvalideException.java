public class MontantInvalideException extends Exception {
    public MontantInvalideException(String message) {
        super(message);
    }
}