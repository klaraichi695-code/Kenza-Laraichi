public class LimiteDepasseeException extends Exception {
    public LimiteDepasseeException(String message) {
        super(message);
    }
}